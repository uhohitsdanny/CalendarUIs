//
//  UIColors+Custom.swift
//  PootCal
//
//  Created by User on 1/31/18.
//  Copyright © 2018 User. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    
    struct PrimaryPootColor {
        let OceanMist = UIColor(red: 0x73, green: 0xD8, blue: 0xEA, alpha: 1)
    }
}

